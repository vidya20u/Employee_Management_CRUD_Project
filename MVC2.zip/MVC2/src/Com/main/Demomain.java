package Com.main;

import Com.view.EmployeeView;

public class Demomain {

	public static void main(String[] args) {
		new EmployeeView();

	}

}
