package Com.view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import Com.Controller.EmployeeController;

public class EmployeeView {
	public JLabel l1,l2,l3,l4;
	public JTextField tf1,tf2,tf3,tf4;
	public JButton b1,b2,b3,b4,b5,b6,b7;
	public JTextArea ta;
	
	public JFrame f;
	
	public EmployeeView()
	{
		f=new JFrame("Employee Management System");
		
		l1=new JLabel("Emp_ID :");
		tf1=new JTextField();
		
		l2=new JLabel("Name :");
		tf2=new JTextField();
		
		l3=new JLabel("Address :");
		tf3=new JTextField();
		
		l4=new JLabel("Salary :");
		tf4=new JTextField();
		Font fo=new Font("Liberation Serif",Font.BOLD,16);
		l1.setFont(fo);
		l2.setFont(fo);
		l3.setFont(fo);
		l4.setFont(fo);
		
		b1=new JButton("Insert");
		b2=new JButton("Delete");
		b3=new JButton("Update");
		b4=new JButton("Search");
		
		ta=new JTextArea();
		b5=new JButton("Show All");
		
		b6=new JButton("Clear All");
		b7=new JButton("Cancel");
		
		l1.setBounds(10, 10, 100, 40);
		tf1.setBounds(120, 10, 150, 30);
		
		l2.setBounds(10, 60, 100, 40);
		tf2.setBounds(120, 60, 150, 30);
		
		l3.setBounds(10, 110, 100, 40);
		tf3.setBounds(120, 110, 150, 30);
		
		l4.setBounds(10, 160, 100, 40);
		tf4.setBounds(120, 160, 150, 30);
		
		b1.setBounds(10, 210, 100, 40);
		b2.setBounds(120, 210, 100, 40);
		b3.setBounds(230, 210, 100, 40);
		b4.setBounds(340, 210, 100, 40);
		
		ta.setBounds(10, 260, 430, 200);
		b5.setBounds(450, 260, 100, 40);
		b6.setBounds(450, 310, 100, 40);
		b7.setBounds(450, 360, 100, 40);
		
		f.add(l1); f.add(tf1);
		f.add(l2); f.add(tf2);
		f.add(l3); f.add(tf3);
		f.add(l4); f.add(tf4);
		
		f.add(b1); f.add(b2); f.add(b3); f.add(b4);
		f.add(ta);
		f.add(b5); f.add(b6); f.add(b7);
		
		
		f.setSize(600, 550);
		f.setLayout(null);
		f.setVisible(true);
		f.getContentPane().setBackground(Color.cyan);
		b1.addActionListener(new EmployeeController(this));
		b2.addActionListener(new EmployeeController(this));
		b3.addActionListener(new EmployeeController(this));
		b4.addActionListener(new EmployeeController(this));
		b5.addActionListener(new EmployeeController(this));
		b6.addActionListener(new EmployeeController(this));
		b7.addActionListener(new EmployeeController(this));
		
	}
}
