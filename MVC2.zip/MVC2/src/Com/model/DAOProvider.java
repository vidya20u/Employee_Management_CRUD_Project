package Com.model;

import java.sql.*;
import java.util.List;

public interface DAOProvider 
{
	String DBDRIVER="com.mysql.jdbc.Driver";
	String DBURL="jdbc:mysql://localhost:3306/db";
	String DBUSER="root";
	String DBPASS="tiger";
	
	int insertdata(Employee em)throws ClassNotFoundException,SQLException;
	int deletedata(int id)throws ClassNotFoundException,SQLException;
	int updatedata(int id,String name,String addr,float sal)throws ClassNotFoundException,SQLException;
	Employee searchdata(Employee em)throws ClassNotFoundException,SQLException;
	public List<Employee> showAll()throws ClassNotFoundException,SQLException;
	
	
	

}
